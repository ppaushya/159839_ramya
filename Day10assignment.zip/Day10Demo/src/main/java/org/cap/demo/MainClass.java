package org.cap.demo;

public class MainClass {

	
	
	public static void main(String[] args) {
	Sender<String> str=new Sender<String>();
	str.setMessage("hello");
	System.out.println(str.getMessage());
	
	Sender<Integer> str1=new Sender<Integer>();
	str1.setMessage(123);
	System.out.println(str1.getMessage());
	Sender sender=new Sender<>();
	sender.setMessage("hi");
	System.out.println(sender.getMessage());
	
	}

}
