package org.cap.demo;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Connection;
public class TestJDBC {
	public static void main(String[] args)
	{
		
			Connection connection=null;
			try{
				//loading the class
				Class.forName("com.mysql.jdbc.Driver");
			//connection establishment
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/mydb", "root","India123");
			String sql="create table employee(empid int primary key,firstname varchar(25) not null,"+"lastname varchar(25),salary numeric(8,2),empdoj date)";
		
			Statement statement =connection.createStatement();
			boolean flag=statement.execute(sql);
			if(!flag)
				System.out.println("Table created successfully");
			
			}catch(ClassNotFoundException| SQLException e)
			{
				e.printStackTrace();
				
			}
			finally
			{
				try {
					connection.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
	}

}
