package org.cap.demo;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class UserInteraction {
	Scanner scanner=new Scanner(System.in);
	EmployeeDao employeeDao=new EmployeeDaoImpl();
	
	
	public int promptEmployeeID() {
		System.out.println("Enter Employee Id:");
		return scanner.nextInt();
	}

	public String promptEmployeeFName() {
		System.out.println("Enter Employee f name u want to set:");
		return scanner.next();
	}

	public String promptEmployeeLName() {
		System.out.println("Enter Employee last name u want to set:");
		return scanner.next();
	}


	public double promptEmployeeSalary() {
		System.out.println("Enter Employee Salary u want to set:");
		return scanner.nextDouble();
	}

	public Employee createEmployee() {
		Employee employee=new Employee();
		System.out.println("Enter Employee Id:");
		employee.setEmpId(scanner.nextInt());
		
		System.out.println("Enter Employee FirstName:");
		employee.setFirstName(scanner.next());
		
		System.out.println("Enter Employee LastName:");
		employee.setLastName(scanner.next());
		
		System.out.println("Enter Employee Salary:");
		employee.setSalary(scanner.nextDouble());
		
		System.out.println("Enter Employee DateOf Joining[yyyy-mm-dd]:");
		String[] date=scanner.next().split("-");
		employee.setEmpdoj(LocalDate.of(
				Integer.parseInt(date[0]), 
				Integer.parseInt(date[1]), 
				Integer.parseInt((date[2]))));
		return employee;
		
		
	}
	public void printEmployee(Employee employee) {
		System.out.println("EmployeeId\tFirstName\tLastName\tSalary\tDateOfjoining");
		
			System.out.println(employee.getEmpId() +"\t\t"
					+employee.getFirstName()+"\t" 
					+employee.getLastName()+"\t" 
					+employee.getSalary()+"\t" 
					+employee.getEmpdoj() );
		
	}
	
	
				
	public void printAllEmployees(List<Employee> employees) {
		System.out.println("EmployeeId\tFirstName\tLastName\tSalary\t\tDateOfjoining");
		for(Employee employee:employees)
			System.out.println(employee.getEmpId() +"\t\t"
					+employee.getFirstName()+"\t\t" 
					+employee.getLastName()+"\t\t" 
					+employee.getSalary()+"\t\t" 
					+employee.getEmpdoj() );
		
	}

}
