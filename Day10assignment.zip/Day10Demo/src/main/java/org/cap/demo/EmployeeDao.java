package org.cap.demo;

import java.util.List;

public interface EmployeeDao {
	
	public void createEmployee(Employee employee);
	public void deleteEmployee(int employeeId);
	
	public List<Employee>  getAllEmployees();
	public Employee findEmployee(int emp1Id);
	public void UpdateEmployeefname(int emp1Id,String s1);
	public void UpdateEmployeelname(int emp1Id,String s1);
	public void UpdateEmployeeSal(int emp1Id,Double s1);

}
