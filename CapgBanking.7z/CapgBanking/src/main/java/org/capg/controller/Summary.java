package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.capg.model.Transaction;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;


@WebServlet("/Summary")
public class Summary extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
    public Summary() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession(true);
		List<Transaction> transaction=new ArrayList<>();
		ILoginService loginservice=new LoginServiceImpl();
		PrintWriter out =response.getWriter();
		String frmDate=request.getParameter("fromdate");
		String toDate=request.getParameter("todate");
		transaction=loginservice.getAlltransactions();
		
			
		  out.println("<html>\r\n" + 
		  		"<head>\r\n" + 
		  		"<meta charset=\"ISO-8859-1\">\r\n" + 
		  		"<title>TransactionSummary</title>\r\n" +
		  		//"<script type=\"text/javascript\" src=\"script/FundTransferfunc.js\">"+"</script>"+
		  		"</head>\r\n" + 
		  		"<body>\r\n" +  
		  		"	<div>\r\n" + 
		  		"		<table>\r\n" + 
		  		"			<tr>\r\n" + 
		  		"				<th colspan=\"3\">TransactionSummary</th>\r\n" + 
		  		"			</tr>\r\n" + 
		  		"			<tr>\r\n" + 
		  		"<td>from date:</td><td>");out.println(frmDate);
		  		out.println("</td>\t<td>To date:</td><td>");out.println(toDate);
		  		out.println("</td></tr>\r\n<tr><th>Date</th><th>from_acc</th>"
		  				+ "<th>To_acc</th><th>trans_type</th><th>Amount</th></tr>");
		  		for(Transaction tra:transaction) {
		  		out.println("<tr><td>"+tra.getTansactionDate()+"</td>");
		  		out.println("<td>"+tra.getFromAccount().getAccountNumber()+"</td>");
		  		out.println("<td>"+tra.getToAccount().getAccountNumber()+"</td>");
		  		out.println("<td>"+tra.getTransactionType()+"</td>");
		  		out.println("<td>"+tra.getAmount()+"</td>"+"</tr>");
		  				  		
		  		}
		  		out.println("</table>\r\n" + "<table>"+"<tr><th>Current Balance in your acount is</th><th></th>"
		  				+ "</table>\r\n</body></html>");
		  		
	}

}
