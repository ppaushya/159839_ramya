package org.capg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.capg.model.Account;
import org.capg.model.Transaction;
import org.capg.service.ILoginService;
import org.capg.service.LoginServiceImpl;


@WebServlet("/PerformTransImpl")
public class PerformTransImpl extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ILoginService loginservice=new LoginServiceImpl();
    public PerformTransImpl() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.sendRedirect("/performTrans");
		Transaction trans=new Transaction();
		 PrintWriter out =response.getWriter();
			String acnt=request.getParameter("accnt");
			String choice=request.getParameter("choice");
			String transAmount=request.getParameter("amount");
			String des=request.getParameter("description");
			String[] arr=acnt.split("-");
			int accNo=Integer.parseInt(arr[0]);
			String accType=arr[1];
			//Account frmAccount=new Account();
			Account toAccount=new Account();
			toAccount=loginservice.getdetails_ToAccount(accNo);
			if(choice=="Deposit") {
			toAccount.setOpeningBalance(toAccount.getOpeningBalance()+Double.parseDouble(transAmount));
			trans.setTransactionType(choice);
			}
			else if(choice=="Withdraw" && toAccount.getOpeningBalance()>Double.parseDouble(transAmount)) {
				toAccount.setOpeningBalance(toAccount.getOpeningBalance()-Double.parseDouble(transAmount));
				trans.setTransactionType(choice);
			}
			else {
				out.println("<p>invalid choice</p>");
				response.sendRedirect("/performTrans");
			}
			loginservice.createToaccount(toAccount);
			trans.setAmount(Double.parseDouble(transAmount));
			trans.setDescription(des);
			trans.setFromAccount(toAccount);
			trans.setTansactionDate(LocalDate.now());
			trans.setToAccount(null);
			loginservice.createTransaction(trans);
			out.println("<html>\r\n" + 
			  		"<head>\r\n" + 
			  		"<meta charset=\"ISO-8859-1\">\r\n" + 
			  		"<title>Deposit/Withdrawal</title>\r\n" + 
			  		
			  		"</head>\r\n" + 
			  		"<body>\r\n" + 
			  		"<p>Transaction Successful..\r\n your current bal of " );
			out.println(toAccount.getAccountNumber());
			out.println("is </p>");
			out.println(toAccount.getOpeningBalance());
			//response.sendRedirect("performTrans");
			}
		
	}


