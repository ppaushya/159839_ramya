package org.capg.hbms.dao;

import org.capg.hbms.model.Users;

public interface ILoginDao {
	public Users getUser(Users user);
	
}
