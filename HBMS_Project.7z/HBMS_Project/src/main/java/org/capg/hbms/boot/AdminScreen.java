package org.capg.hbms.boot;

import java.util.Scanner;

import org.capg.hbms.model.Hotel;
import org.capg.hbms.model.RoomDetails;
import org.capg.hbms.service.HotelServiceImpl;
import org.capg.hbms.service.IHotelService;
import org.capg.hbms.service.IRoomService;
import org.capg.hbms.service.RoomServiceImpl;
import org.capg.hbms.view.AdminInteraction;

public class AdminScreen {
	static Scanner scanner=new Scanner(System.in);
	static IHotelService hotelservice=new HotelServiceImpl();

	public static void HotelManagement()
	{
		AdminInteraction admininteraction=new AdminInteraction();
		System.out.println("Choose Functionality");
		System.out.println("1. Add Hotel");
		System.out.println("2.Delete Hotel");
		System.out.println("3.Modify Hotel");
		
		int choice=scanner.nextInt();
		switch(choice)
		{
		case 1:
			Hotel hotel1=admininteraction.PromptHotel();
			hotelservice.addHotel(hotel1);
			
			break;
		case 2:
			
			int hotelid=admininteraction.DeleteHotel();
			hotelservice.deleteHotel(hotelid);
			
		break;
		case 3:
			int choice1=admininteraction.modifyHotel();
			switch(choice)
			{
			case 1:
				
				break;
			case 2:
				break;
			case 3:
				break;
				default:
					System.out.println("Invalid Option");
					break;
			}
			
			break;
		default:
			System.out.println("Invalid Option");
			break;
		}
		
	}
	
	public static void RoomManagement()
	{
		AdminInteraction admininteraction=new AdminInteraction();
		System.out.println("Choose Functionality");
		System.out.println("1. Add Room");
		System.out.println("2.Delete Room");
		System.out.println("3.Modify Room");
		int choice=scanner.nextInt();
		IRoomService roomservice=new RoomServiceImpl();
		switch(choice)
		{
		case 1:
			RoomDetails room=new RoomDetails();
			room=admininteraction.promptRoom();
			roomservice.addroom(room);
			
			break;
		case 2:
			int roomid;
			roomid=admininteraction.promptRoomid();	
			roomservice.deleteRoom(roomid);
			
		break;
		case 3:
			System.out.println("Choose Functionality");
			System.out.println("1.change availability");
			System.out.println("2.change room Name");
			System.out.println("3.change per Night Cost");
			int option=scanner.nextInt();
			switch(option)
			{
			case 1:
				RoomDetails roomd=admininteraction.changeAvailability();
				
				roomservice.setAvailability(roomd);
				break;
			case 2:
				
				RoomDetails roomdetail=admininteraction.changeRoomType();
				
				roomservice.changeRoomType(roomdetail);
			case 3:
				
				RoomDetails roomdetail2=admininteraction.changeRoomCost();
				
				roomservice.changeRoomCost(roomdetail2);
				
				break;
				default:
					System.out.println("Invalid Option");
					break;
			}
			
			break;
		default:
			System.out.println("Invalid Option");
			break;
		}
		
	}
	
	public static void GenerateReports()
	{
		System.out.println("Choose Functionality");
		System.out.println("1.View List of hotels");
		System.out.println("2.View Guest List of specific Hotel");
		System.out.println("3.View Bookings for specific Hotel");
		System.out.println("4.View Bookings for specific Date");
	}
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Choose functionality");
		System.out.println("1.Hotel Management");
		System.out.println("2.Room Management");
		System.out.println("3.Generate Reports");
		int choice=scanner.nextInt();
		switch(choice)
		{
		case 1:
			HotelManagement();
			break;
		case 2:
			RoomManagement();
		break;
		case 3:
			GenerateReports();
			break;
		default:
			System.out.println("Invalid Option");
			break;
		}
		
		
		
	}

}
