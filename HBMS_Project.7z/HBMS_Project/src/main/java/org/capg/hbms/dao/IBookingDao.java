package org.capg.hbms.dao;

import org.capg.hbms.model.BookingDetails;

public interface IBookingDao {
	
public void addbooking(BookingDetails bookingdetails);

}
