package org.capg.hbms.service;

import org.capg.hbms.model.Users;

public interface IRegistrationService {
	public Users createUser(Users user); 
}
