package org.capg.hbms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.capg.hbms.model.BookingDetails;
import org.capg.hbms.model.RoomDetails;
import org.capg.hbms.model.RoomType;
import org.capg.hbms.model.Users;

public class RoomDaoImpl implements IRoomDao {

	@Override
	public void addRoom(RoomDetails room) {
		 String sql="insert into RoomDetails(hotel_id,room_no,room_type,per_night_rate,availability,photo) values(?,?,?,?,?,?);";
			
			
			try(Connection connection=getConnection())
			{
				
				PreparedStatement statement=connection.prepareStatement(sql);
				statement.setInt(1, room.getHotel_id());
				statement.setString(2,room.getRoom_no());
				statement.setString(3,room.getRoom_type().toString());
				statement.setDouble(4,room.getPer_night_rate());
				statement.setBoolean(5,room.isAvailability());
				statement.setString(6,room.getPhoto());
				System.out.println(room);
				int row=statement.executeUpdate();
				
				if(row>0)
					System.out.println(" Room added  successfully!");
			
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		
		
	}

	@Override
	public List<RoomDetails> getRooms(int hotel_id) {
		List<RoomDetails> roomdetails=new ArrayList();
		String sql="select * from RoomDetails where hotel_id=?;";
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setInt(1,hotel_id );
			
		  ResultSet res=statement.executeQuery();
			while(res.next())
			{
				RoomDetails roomd=new RoomDetails();
				roomd.setHotel_id(hotel_id);
				roomd.setRoom_id(res.getInt(2));
				roomd.setRoom_type(RoomType.valueOf(res.getString(3)));
				roomd.setPer_night_rate(res.getDouble(4));
				roomd.setAvailability(res.getBoolean(5));
				roomd.setPhoto(res.getString(6));
				roomd.setRoom_no(res.getString(7));
				roomdetails.add(roomd);
				
			}
			
			return roomdetails;
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return null;
	}
	
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/hbms_db", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public Double roomRate(int roomid) {
		Double roomCost = null;
		String sql="select * from RoomDetails where room_id=?;";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setInt(1,roomid );
			
		  ResultSet res=statement.executeQuery();
			while(res.next())
			{
				roomCost=res.getDouble(4);
			
				
			}
			
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return roomCost;
	}

	@Override
	public void changeAvailability(RoomDetails finalroom) {
		
		int roomId=finalroom.getRoom_id();
		Boolean availability;
		if(finalroom.isAvailability()==true) {
			availability=false;
		}
		else
			availability=true;
		String sql="UPDATE RoomDetails SET availability = ? where room_id=?;";
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setBoolean(1,availability );
			statement.setInt(2,roomId );
			int row=statement.executeUpdate();
			
			if(row>0)
				System.out.println(" Room Availability  updated  successfully!");
			
		
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
	
	
	
	}

	@Override
	public RoomDetails getRoom_withID(int room_id) {
		
	RoomDetails roomDetails=new RoomDetails();
String sql="select * from RoomDetails where room_id=? and availability=1;";
		
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setInt(1,room_id );
			
		  ResultSet res=statement.executeQuery();
			while(res.next())
			{
				roomDetails.setHotel_id(res.getInt(1));
				roomDetails.setRoom_id(room_id);
				roomDetails.setRoom_type(RoomType.valueOf(res.getString(3)));
				roomDetails.setPer_night_rate(res.getDouble(4));
				roomDetails.setAvailability(res.getBoolean(5));
				roomDetails.setPhoto(res.getString(6));
				roomDetails.setRoom_no(res.getString(7));
			}
		
	}catch (SQLException e) {
		
		e.printStackTrace();
	}
		return roomDetails;
	}

	@Override
	public void deleteRoom(int roomid) {
		
		String sql="Delete from RoomDetails where room_id=?;";
		try(Connection connection=getConnection())
		{
		PreparedStatement statement=connection.prepareStatement(sql);
		statement.setInt(1, roomid);
		int row=statement.executeUpdate();
		
		if(row>0)
			System.out.println(" Room with id "+roomid+" deleted successfully");
	
	}catch (SQLException e) {
		
		e.printStackTrace();
	}
}

	@Override
	public void setAvailability(RoomDetails roomd) {
		int roomId=roomd.getRoom_id();
		Boolean availability=roomd.isAvailability();
		String sql="UPDATE RoomDetails SET availability = ? where room_id=?;";
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setBoolean(1,availability );
			statement.setInt(2,roomId );
			int row=statement.executeUpdate();
			
			if(row>0)
				System.out.println(" Room Availability  updated  successfully!");
			
		
	} catch (SQLException e) {
		
		e.printStackTrace();
	}		
	}

	@Override
	public void changeRoomType(RoomDetails roomdetail) {
		int roomId=roomdetail.getRoom_id();
		String roomType=(roomdetail.getRoom_type()).toString();
		String sql="UPDATE RoomDetails SET room_type = ? where room_id=?;";
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setString(1, roomType);
			statement.setInt(2, roomId);
			int row=statement.executeUpdate();
			
			if(row>0)
				System.out.println(" Room Type  updated  successfully!");
			
		
	} catch (SQLException e) {
		
		e.printStackTrace();
	}		
		
	
}

	@Override
	public void changeRoomCost(RoomDetails roomdetail) {
		int roomId=roomdetail.getRoom_id();
		Double cost=roomdetail.getPer_night_rate();
		String sql="UPDATE RoomDetails SET per_night_rate = ? where room_id=?;";
		try(Connection connection=getConnection())
		{
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setDouble(1, cost);
			statement.setInt(2, roomId);
			int row=statement.executeUpdate();
			
			if(row>0)
				System.out.println(" Room rate per night  updated  successfully!");
			
		
	} catch (SQLException e) {
		
		e.printStackTrace();
	}		
	}
}
