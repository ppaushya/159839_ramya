package org.capg.hbms.service;

import java.time.temporal.ChronoUnit;

import org.capg.hbms.dao.BookingDaoImpl;
import org.capg.hbms.dao.IBookingDao;
import org.capg.hbms.model.BookingDetails;
import org.capg.hbms.view.UserInteraction;

public class BookingServiceImpl implements IBookingService {
IBookingDao bookingdao=new BookingDaoImpl();
IRoomService roomService=new RoomServiceImpl();

	@Override
	public void addbooking(BookingDetails bookingdetails) {
		bookingdao.addbooking(bookingdetails);
		
	}
public BookingDetails findAmount(BookingDetails bookingDetails,int count)
{
	
	
	int roomid=bookingDetails.getRoom_id();
	Double roomRate=roomService.roomRate(roomid);
long days=ChronoUnit.DAYS.between(bookingDetails.getBooked_to(),bookingDetails.getBooked_from());
	
	Double totalAmount=Double.valueOf(count)*roomRate*days;
	
		
	bookingDetails.setAmount(totalAmount);
	return bookingDetails;
}

}
