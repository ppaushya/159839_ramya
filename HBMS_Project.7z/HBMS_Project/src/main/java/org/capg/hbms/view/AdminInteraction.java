package org.capg.hbms.view;

import java.util.Scanner;

import org.capg.hbms.model.Hotel;
import org.capg.hbms.model.RoomDetails;
import org.capg.hbms.model.RoomType;

public class AdminInteraction {
	Scanner sc=new Scanner(System.in);
public Hotel PromptHotel()
{
	Hotel hotel=new Hotel();
	System.out.println("Enter city");
	hotel.setCity(sc.next());
	System.out.println("Enter Hotel name");
	hotel.setHotel_name(sc.next());
	System.out.println("Enter Address");
	hotel.setAddress(sc.next());
	System.out.println("Enter description");
	hotel.setDescription(sc.next());
	System.out.println("Enter phone no ");
	hotel.setPhone_no1(sc.next());
	System.out.println("Enter alternate phone number");
	hotel.setPhone_no2(sc.next());
	System.out.println("Enter Average cost per night");
	hotel.setAvg_rate_per_night(sc.nextDouble());
	System.out.println("Enter rating");
	hotel.setRating(sc.next());
	System.out.println("Enter email");
	hotel.setEmail(sc.next());
	System.out.println("Enter fax");
	hotel.setFax(sc.next());
	return hotel;
	
}
public int DeleteHotel()
{
	System.out.println("Enter the id of the hotel u want to delete ");
	int id=sc.nextInt();
	return id;
}
public int modifyHotel()
{
	System.out.println("choose what you want to modify.");
	System.out.println("1.Description");
	System.out.println("2.Hotel Name");
	System.out.println("3.Average Rate per night");
	int choice =sc.nextInt();
	return choice;
	
}
public RoomDetails promptRoom() {
	RoomDetails room=new RoomDetails();
	
	System.out.println("Enter Room no");
	room.setRoom_no(sc.next());
	System.out.println("Enter HotelId");
	room.setHotel_id(sc.nextInt());
	System.out.println("Enter Room Type");
	room.setRoom_type(RoomType.valueOf(sc.next()));
	System.out.println("Enter per Night Rate");
	room.setPer_night_rate(sc.nextDouble());
	System.out.println("Choose Photo");
	room.setPhoto(sc.next());
	room.setAvailability(true);	
	return room;
}
public int promptRoomid() {
	System.out.println("Enter RoomId");
	int roomId=sc.nextInt();
	return roomId;
}

public RoomDetails changeAvailability() {
	RoomDetails roomd=new RoomDetails();
	System.out.println("Enter RoomId to alter availability");
	int roomId=sc.nextInt();
	System.out.println("enter availability you want to set");
	Boolean avai=sc.hasNextBoolean();
	roomd.setAvailability(avai);
	roomd.setRoom_id(roomId);
	return roomd;

}
public RoomDetails changeRoomType() {
	RoomDetails roomd=new RoomDetails();
	System.out.println("Enter RoomId to change room type");
	roomd.setRoom_id(sc.nextInt());
	System.out.println("enter room type you want to set");
	roomd.setRoom_type(RoomType.valueOf(sc.next()));
	return roomd;
}
public RoomDetails changeRoomCost() {
	RoomDetails roomd=new RoomDetails();
	System.out.println("Enter RoomId to change room cost");
	roomd.setRoom_id(sc.nextInt());
	System.out.println("enter cost you want to set");
	roomd.setPer_night_rate(sc.nextDouble());
	return roomd;
}
}
