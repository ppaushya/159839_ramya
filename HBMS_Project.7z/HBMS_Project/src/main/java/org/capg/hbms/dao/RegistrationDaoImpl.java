package org.capg.hbms.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.capg.hbms.model.Users;

public class RegistrationDaoImpl implements IRegistrationDao {

	@Override
	public Users createUser(Users user) {
		
     String sql="insert into users(password,role,user_name,mobile_no,phone,address,email) values(?,?,?,?,?,?,?);";
		
		
		try(Connection connection=getConnection())
		{
			
			PreparedStatement statement=connection.prepareStatement(sql);
			statement.setString(1,user.getPassword());
			statement.setString(2,user.getRole());
			statement.setString(3, user.getUser_name());
			statement.setString(4,user.getMobile_no());
			statement.setString(5,user.getPhone());
			statement.setString(6,user.getAddress());
			statement.setString(7,user.getEmail());

			int row=statement.executeUpdate();
			
			if(row>0)
				System.out.println(row+" User Registered successfully!");
		
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return null;
	}
	
	
	
	
	
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/hbms_db", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}


	
}
