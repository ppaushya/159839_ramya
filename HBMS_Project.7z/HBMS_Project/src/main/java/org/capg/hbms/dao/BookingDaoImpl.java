package org.capg.hbms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.capg.hbms.model.BookingDetails;

public class BookingDaoImpl implements IBookingDao {

	@Override
	public void addbooking(BookingDetails bookingdetails) {
		
		
		 String sql="insert into BookingDetails(room_id,user_id,booked_from,booked_to,no_of_adults,no_of_children,amount) values(?,?,?,?,?,?,?);";
			
			
			try(Connection connection=getConnection())
			{
				
				PreparedStatement statement=connection.prepareStatement(sql);
				statement.setInt(1,(bookingdetails.getRoom_id()));
				statement.setInt(2,(bookingdetails.getUser_id()));
				statement.setDate(3, Date.valueOf(bookingdetails.getBooked_from()));
				statement.setDate(4, Date.valueOf(bookingdetails.getBooked_to()));
				statement.setInt(5,bookingdetails.getNo_of_adults() );
				statement.setInt(6,bookingdetails.getNo_of_children() );
				statement.setDouble(7,bookingdetails.getAmount());
				int row=statement.executeUpdate();
				
				if(row>0)
					System.out.println(row+" bookingdetails added  successfully!");
			
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		
		
	}
	
	private Connection getConnection()
	{
		Connection connection=null;
		try	{
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/hbms_db", "root", "India123");
			return connection;
		}
		catch(ClassNotFoundException | SQLException e)	{
			e.printStackTrace();
		}
		return null;
	}


}
