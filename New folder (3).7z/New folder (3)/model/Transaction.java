package org.cap.model;

import java.time.LocalDate;

public class Transaction {
private long transactionId;
private LocalDate tansactionDate;
private Account fromAccount;
private Account toAccount;
private double amount;
private String transactionType;
private String description;


}
