package org.cap.dao;

public class ICustomerDao {

}
