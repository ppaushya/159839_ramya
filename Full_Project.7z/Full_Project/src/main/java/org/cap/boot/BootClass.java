package org.cap.boot;

import org.cap.model.Customer;
import org.cap.service.CustomerServiceImpl;
import org.cap.service.ICustomerService;
import org.cap.view.UserInteraction;

public class BootClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
UserInteraction userinteraction =new UserInteraction();
Customer customer=new Customer();
customer=userinteraction.createCustomer();

	}

}
