package org.cap.view;
import java.util.Scanner;
import org.cap.model.Customer;
import org.cap.service.CustomerServiceImpl;
import org.cap.service.ICustomerService;

public class UserInteraction {
	Scanner scanner=new Scanner(System.in);
	ICustomerService customerservice=new CustomerServiceImpl();
	public Customer createCustomer() {
		Customer customer=new Customer();
		customer.setRegistrationId(322);
		System.out.println("Enter Customer name");
		customer.setCustomerName(scanner.next());
		System.out.println("enter mobile no");
		customer.setMobileNo(scanner.next());
		if(validateCustomername(customer.getCustomerName()))
			{
		if(validateMobileno(customer.getMobileNo()))
		{
		System.out.println("enter age");
		customer.setAge(scanner.nextInt());
		System.out.println("enter registration fee");
		customer.setRegistrationFee(scanner.nextDouble());

		customer.setActualRegFee(customerservice.calculateRegFee(customer.getRegistrationFee(),customer.getAge()));
		
		
	}
				}
		else {
			System.out.println("enter valid details");
			System.exit(0);
		}
		return customer;
	}
	private boolean validateMobileno(String mobileNo) {
		if(mobileNo.matches("[0-9]{10}")) {
			return true;
		}
		return false;
		
		
	}
	
	private boolean validateCustomername(String customerName) {
		if(customerName.matches("[A-z]{1}[a-zA-Z]{3,}")) {
			return true;
		}
		return false;
		
		
	}

}
