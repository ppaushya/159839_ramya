package org.cap.model;

public class Customer {
int registrationId;
String CustomerName;
String mobileNo;
double registrationFee;
int age;
double actualRegFee;
public Customer() {

}
public Customer(int registrationId, String customerName, String mobileNo, double registrationFee, int age,
		double actualRegFee) {
	
	this.registrationId = registrationId;
	CustomerName = customerName;
	this.mobileNo = mobileNo;
	this.registrationFee = registrationFee;
	this.age = age;
	this.actualRegFee = actualRegFee;
}
public int getRegistrationId() {
	return registrationId;
}
public void setRegistrationId(int registrationId) {
	this.registrationId = registrationId;
}
public String getCustomerName() {
	return CustomerName;
}
public void setCustomerName(String customerName) {
	CustomerName = customerName;
}
public String getMobileNo() {
	return mobileNo;
}
public void setMobileNo(String mobileNo) {
	this.mobileNo = mobileNo;
}
public double getRegistrationFee() {
	return registrationFee;
}
public void setRegistrationFee(double registrationFee) {
	this.registrationFee = registrationFee;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public double getActualRegFee() {
	return actualRegFee;
}
public void setActualRegFee(double actualRegFee) {
	this.actualRegFee = actualRegFee;
}
@Override
public String toString() {
	return "Registration [registrationId=" + registrationId + ", CustomerName=" + CustomerName + ", mobileNo="
			+ mobileNo + ", registrationFee=" + registrationFee + ", age=" + age + ", actualRegFee=" + actualRegFee
			+ "]";
}

}
