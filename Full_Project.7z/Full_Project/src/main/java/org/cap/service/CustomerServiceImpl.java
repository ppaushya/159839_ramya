package org.cap.service;

public class CustomerServiceImpl implements ICustomerService {

	public double calculateRegFee(double registrationFee,int age) {
		double regfee=registrationFee;
		
		double actualfee=0.0;
		if(age>0&&age<18) {
			actualfee=registrationFee;
		}
		else if(age>18&&age<25) {
			actualfee=registrationFee+registrationFee*0.1;
		}
		else if(age>25&&age<50) {
			actualfee=registrationFee+registrationFee*0.2;
		}
		else
		{
			actualfee=registrationFee+registrationFee*0.3;
		}
		return actualfee;
		// TODO Auto-generated method stub
		
	}

}
