package org.cap.service;

public interface ICustomerService {

	public double calculateRegFee(double registrationFee, int i);
		

}
