import { Component } from "@angular/core";

@Component({
    selector:'pm-registration',
    templateUrl:'./registration.html'
    })
    export class RegistrationComponent{

    }