import { Component } from "@angular/core";


@Component({
    selector:'pm-deposit',
    templateUrl:'./deposit.component.html'
    
    })
export class DepositComponent{

}