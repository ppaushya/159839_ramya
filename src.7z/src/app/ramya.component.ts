import { Component } from '@angular/core';

@Component({
  selector: 'my-roots',
  template: "<h1> My {{title}}!!</h1>",
 
 
  styleUrls: ['./ramya.component.css']
})
export class myComponent {
  title = 'Banking';
}
