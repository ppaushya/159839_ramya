import { Component } from "@angular/core";

@Component({
    selector:'pm-transactions',
    templateUrl:'./transaction.component.html'
    })
    export class TransactionComponent{

    }