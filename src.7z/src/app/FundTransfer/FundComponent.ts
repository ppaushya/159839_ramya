import { Component } from "@angular/core";


@Component({
    selector:'pm-fund',
    templateUrl:'./FundComponent.html'
    
    })
export class FundComponent{

}