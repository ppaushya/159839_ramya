import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { myComponent } from './ramya.component';
import { AppComponent } from './app.component';
import { ProductListComponent } from './products/products-list.component';
import{FormsModule} from '@angular/forms';
import { ConvertToSpacesPipe } from './shared/convert-to-spaces.pipe';
import { StarComponent } from './shared/star.component';
import { ProductService } from './products/product.service';
import { HttpClientModule } from '@angular/common/http';
import { ProductDetailComponent } from './products/product-detail.component';
import{RouterModule} from '@angular/router';
import { WelcomeComponent } from './home/welcome.component';
import { DepositComponent } from './deposit/deposit component';
import { TransactionComponent } from './transaction/transaction.component';
import { FundComponent } from './FundTransfer/FundComponent';
import { TransSummary } from './summary/summary';
import { RegistrationComponent } from './registration/registration';


// import { TransactionComponent } from './transaction/transaction.component';
@NgModule({
  declarations: [
      AppComponent,ProductListComponent,ConvertToSpacesPipe,StarComponent,
       ProductDetailComponent,WelcomeComponent,DepositComponent,
       TransactionComponent,FundComponent,TransSummary,RegistrationComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot([
      // {path:'products',component:ProductListComponent},
      {path:'deposit',component:DepositComponent},
      {path:'transaction',component:TransactionComponent},
      {path:'fundTransfer',component:FundComponent},
      // {path:'products/:id',component:ProductDetailComponent},
      {path:'welcome',component:WelcomeComponent},
      {path:'summary',component:TransSummary},
      {path:'registration',component:RegistrationComponent},
      {path:'',redirectTo:'welcome',pathMatch:'full'},
      // {path:'**',redirectTo:'welcome',pathMatch:'full'},


    ])

  ],
 
  bootstrap: [AppComponent]
})
export class AppModule { }
