import { OnInit, Component } from "@angular/core";
import { NgIf, NgFor, NgForOf } from "@angular/common";
import{IDetails} from "./details";
import { ActivatedRoute, Router } from "@angular/router";

@Component({
 
    templateUrl: './deposit/deposit.component.html',
    
  })

  export class MyBanking {
    pageTitle:string ='Capg Banking';
    _username:string;
    _password:string;
    constructor(private _route:ActivatedRoute,private _router:Router) {
    
    }
    get username():string{
        return this._username;
    }
    set username(value:string){
        this. _username=value;
        // this.username!=null?this.validate(this._username):this.invalidate();
       
    }

    get password():string{
        return this._username;
    }
    set password(value:string){
        this. _password=value; 
        // this.password!=null?this.validate(this. _password):this.invalidate();
    }
     Details:IDetails[];
// validate(username:string):boolean{
//     let flag:boolean=false;
//     *ngFor(let detail of Details){   
//         *NgIf(username==detail){
//             flag=!flag;
//             break;
//         }

//     }
//     return flag;
// }

bankingService(){
    alert('dhf');
    this._router.navigate(['/registration']);//('./registration/registration.html');
}
bankService1(){
    alert('signin');
}

invalidate():boolean{
    return false;
}
ngOnInit():void{
      
        // this._bankService.getdetails()
        // .subscribe(banking=>{
        //     this.banking=banking;
           
        // },
        // error=>this.errorMessage=<any>error);     
    }
  }