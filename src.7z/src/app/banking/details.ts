export interface IDetails{
    userName:string;
    password:string;
}