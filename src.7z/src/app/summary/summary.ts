import { Component } from "@angular/core";


@Component({
    selector:'pm-summary',
    templateUrl:'./summary.html'
    
    })
export class TransSummary{

}