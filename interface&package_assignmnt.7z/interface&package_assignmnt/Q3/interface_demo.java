package org.cap.exe;

interface calculation{
	
	double  division(int a,int b);
	double  modulo(int a,int b);
}
public class interface_demo {
double res1;
double res2;
public double division(int a,int b) {
	res1=a/b;
	return res1;
}
public double modulo(int a,int b) {
	res2=a%b;
	return res2;
}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
interface_demo d=new interface_demo();
System.out.println("division of 2 numbers is"+d.division(12,3));
System.out.println("modulo of 2 numbers is"+d.modulo(12,3));
	}

}
