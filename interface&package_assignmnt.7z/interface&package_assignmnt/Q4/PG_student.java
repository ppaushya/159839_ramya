package org.cap.exe;
interface student{
	 void display_grade(int marks);
	void display_attendence(int days);
	}
public  class PG_student implements student{
	
	public void display_grade(int marks) {
		int m=marks;
		if(m<=50) {
			System.out.println("Grade is C ");
		}
		if(m>50&&m<70) {
			System.out.println("Grade is B ");
		}
		if(m<100&&m>70) {
			System.out.println("Grade is A ");
		}
	}
	

	@Override
	public void display_attendence(int days) {
		// TODO Auto-generated method stub
		int d;
		d=days;
		if(days<=28) {
			System.out.println("%attendence is 40% ");
		}
		if(days<46&&days<28) {
			System.out.println("%attendence is 60% ");
		}
		if(days>48) {
			System.out.println("%attendence is 80% ");
		}
	}
}



