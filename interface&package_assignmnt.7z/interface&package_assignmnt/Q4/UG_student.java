package org.cap.exe;

public  class UG_student implements student{
	
	public void display_grade(int marks) {
		int m=marks;
		if(m<=50) {
			System.out.println("Grade is 6.0 ");
		}
		if(m>50&&m<70) {
			System.out.println("Grade is 7.0 ");
		}
		if(m<100&&m>70) {
			System.out.println("Grade is 9.0 ");
		}
	}
	

	@Override
	public void display_attendence(int days) {
		// TODO Auto-generated method stub
		int d;
		d=days;
		if(days<=28) {
			System.out.println("%attendence is 60.0% ");
		}
		if(days<46&&days<28) {
			System.out.println("%attendence is 80.0% ");
		}
		if(days>48) {
			System.out.println("%attendence is 90.0% ");
		}
	}
}



