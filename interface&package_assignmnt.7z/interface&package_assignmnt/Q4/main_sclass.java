package org.cap.exe;
import java.util.Scanner;
public class main_sclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int marks;int days;
		Scanner st=new Scanner(System.in);
	PG_student s=new PG_student();
	UG_student u=new UG_student();
	
	System.out.println("enter pg student marks");
	marks=st.nextInt();
	s.display_grade(marks);
	System.out.println("enter no.of days present");
	days=st.nextInt();
	s.display_attendence(days);
	System.out.println("enter ug student marks");
	marks=st.nextInt();
	s.display_grade(marks);
	System.out.println("enter no.of days present");
	days=st.nextInt();
	s.display_attendence(days);
	}
	}

