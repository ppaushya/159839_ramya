
interface pidemo {
final double pi=3.14;
}
