
public class circle implements pidemo{
	public  void cal_area() {
		double area;
		int r=10;
		area=pi*r*r;
		System.out.println("area is "+area);
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	circle c=new circle();
	c.cal_area();
	}
	}
