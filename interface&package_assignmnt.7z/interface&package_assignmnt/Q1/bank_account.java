package org.cap.exe;
import java.util.Scanner;
import balance.Account;

public class bank_account{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Scanner s=new Scanner(System.in);
	Account ac=new Account();
	int details;
	
	System.out.println("enter acc details");
	details=s.nextInt();
	
	ac.display_balance(details);
	}
}