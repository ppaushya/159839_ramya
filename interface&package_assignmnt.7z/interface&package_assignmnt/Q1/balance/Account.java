package balance;
public class Account {
	public void display_balance(int details) {
		int d=details;
		System.out.println("balance of"+d+"is 50000");
	}
}