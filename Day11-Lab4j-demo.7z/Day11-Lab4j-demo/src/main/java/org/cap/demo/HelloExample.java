package org.cap.demo;

import org.apache.log4j.Logger;

public class HelloExample {
final static Logger logger=Logger.getLogger(HelloExample.class) ;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
HelloExample obj=new HelloExample();
obj.runme("capgemini");
	}
	private void runme(String parameter) {
		if(logger.isDebugEnabled()) {
			logger.debug("Thid is a msg: "+parameter);
		}
		if(logger.isInfoEnabled()) {
			logger.info("this is a info: "+parameter);
		}
		try {
			int num1=43,num2=0;
			int num3=num1/num2;
		}
		catch(ArithmeticException e) {
			logger.error("something went wrong",e);
		}
		logger.warn("this is msg: "+parameter);
		logger.error("this is an error: "+parameter);
		logger.fatal("this is a fatal: "+parameter);
	}

}
