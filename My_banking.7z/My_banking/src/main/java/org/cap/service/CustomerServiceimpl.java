package org.cap.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

import org.cap.dao.CustomerDaoImpl;
import org.cap.dao.ICustomerDao;
import org.cap.model.Account;
import org.cap.model.Customer;

public class CustomerServiceimpl implements ICustomerService{
	
	private ICustomerDao customerDao=new CustomerDaoImpl();
	
	

	
	private boolean isValidCustomer(Customer customer) {
		boolean flag=false;
		
		if(customer.getDob().isBefore(LocalDate.now())) {
			if(customer.getMobile_no().matches("(7|8|9)\\d{9}"))
				flag=true;
			else
				flag=false;
		}else
			flag=false;
		
		
		return flag;
	}

	private boolean isValidAccount(Account account) {
		// TODO Auto-generated method stub
		boolean flag=false;
		if(Long.toString(account.getAccountNumber()).matches("(3|4|5)\\d{10}"))
		
				flag=true;
			
		else
			flag=false;
		return flag;
	}
	
	

	public void createCustomer(Customer customer) {
		// TODO Auto-generated method stub
		if(isValidCustomer(customer)) {
			customerDao.createCustomer(customer);
}

	}



	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customerDao.getAllCustomers();
	}
	public Set<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return customerDao.getAllAccounts();
	}


	public void createAccount(Account account) {
		// TODO Auto-generated method stub
		if(isValidAccount(account)) {
			customerDao.createAccount(account);
}
	}




}
