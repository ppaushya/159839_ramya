package org.cap.service;

import java.util.List;
import java.util.Set;

import org.cap.model.Account;
import org.cap.model.Customer;

public interface ICustomerService {

	public void createCustomer(Customer customer);
	public void createAccount(Account account);
	public List<Customer> getAllCustomers();
	public Set<Account> getAllAccounts();
	
}
