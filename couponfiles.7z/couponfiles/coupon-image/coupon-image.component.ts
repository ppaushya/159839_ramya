import { Component, OnInit } from '@angular/core';
import { Coupon } from '../generate-coupon/coupon';
import { CouponService } from '../generate-coupon/coupon-service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-coupon-image',
  templateUrl: './coupon-image.component.html',
  styleUrls: ['./coupon-image.component.scss']
})
export class CouponImageComponent implements OnInit {

  constructor(private couponService:CouponService) { }
  coupon:Coupon=new Coupon;
  ngOnInit() {
    this.getcoupon();
  }
emailCoupon(coupon):void{
  this.couponService.emailcoupon(coupon);
}
 getcoupon(){
  this.coupon=this.couponService.getCoupon();
}
}
