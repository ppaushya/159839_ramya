import { Component, OnInit } from '@angular/core';
import { Coupon } from './coupon';
import { HttpClient } from 'selenium-webdriver/http';
import { CouponService } from './coupon-service';
import { Observable } from 'rxjs';
import {  Router } from '@angular/router';

@Component({
  selector: 'app-generate-coupon',
  templateUrl: './generate-coupon.component.html',
  styleUrls: ['./generate-coupon.component.scss']
})
export class GenerateCouponComponent implements OnInit {

  coupon:Coupon=new Coupon;
  constructor(private _router: Router,private couponService:CouponService) { }

  sendCoupon(coupon:Coupon):any{
    
    return this.couponService.generatecoupon(coupon).subscribe(coupons =>{
      this.coupon = coupons;
      this.bannerCreation();

  });
  }
   generateCoupon(coupon:Coupon):void{
     this.couponService.setCoupon(coupon);
     this._router.navigate(['coupon/couponpage']);
   }

  bannerCreation():any{}

  ngOnInit() {
  }

}
