package org.cap.view;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
import java.util.logging.Logger;

import org.cap.boot.BootClass;

import org.cap.model.Customer;
import org.cap.service.CustomerServiceImpl;
import org.cap.service.ICustomerService;
import org.cap.utility.util;

public class UserInteraction{
	//final static Logger logger=Logger.getLogger(BootClass.class) ;

	Scanner scanner=new Scanner(System.in);
	ICustomerService customerservice=new CustomerServiceImpl();
	public Customer getdetails() {
		
		util utility=new util();
		Customer customer=new Customer();
		
		System.out.println("Enter Customer name");
		customer.setCustomerName(scanner.next());
		System.out.println("enter mobile no");
		customer.setMobileNo(scanner.next());
		
		if(utility.validateCustomername(customer.getCustomerName()))
			{
		if(utility.validateMobileno(customer.getMobileNo()))
		{
		System.out.println("enter age");
		customer.setAge(scanner.nextInt());
		System.out.println("enter registration fee");
		customer.setRegistrationFee(scanner.nextDouble());

	
		customer.setActualRegFee(customerservice.calculateRegFee(customer.getRegistrationFee(),customer.getAge()));


		}
				}
		else {
			System.out.println("enter valid details");
			System.exit(0);
		}
		return customer;
		}

	public void printdetails(Customer customer) {
		System.out.println("Congrats!!!!");
		System.out.println("registration successfully done");
		System.out.println("your regId: "+customer.getRegistrationId()+"actualregFee: "+customer.getActualRegFee());
	}
}