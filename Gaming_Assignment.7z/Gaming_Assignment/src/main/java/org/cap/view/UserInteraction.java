package org.cap.view;

import java.util.Scanner;

import org.cap.model.Registration;
import org.cap.service.IRegistrationService;
import org.cap.service.RegistrationServiceImpl;
import org.cap.utility.*;



public class UserInteraction {

	public Registration getdetails() {
		// TODO Auto-generated method stub
		Scanner scanner=new Scanner(System.in);
		
		Registration registration = new Registration();
		System.out.println("Enter Customer name");
		registration.setCustName(scanner.next());
		System.out.println("enter mobile no");
		registration.setMobileNo(scanner.next());
		
	util u=new util();
		if(u.validateCustomername(registration.getCustName()))
			{
		if(u.validateMobileno(registration.getMobileNo()))
		{
		System.out.println("enter age");
		registration.setAge(scanner.nextInt());
		System.out.println("enter registration fee");
		registration.setRegFees(scanner.nextDouble());

	
		
//		registration.setActualRegFee(regservice.calculateRegFee(registration.getRegistrationFee(),registration.getAge()));

		}
			}
	else {
		System.out.println("enter valid details");
		System.exit(0);
	}
	return registration;
	}

	public void printAcknowledgement(Registration registration2) {
		System.out.println("Congrats!!!!");
		System.out.println("registration successfully done");
		System.out.println("your regId: "+registration2.getRegistrationId()+"actualregFee: "+registration2.getActualRegFees());
		
	}
	}