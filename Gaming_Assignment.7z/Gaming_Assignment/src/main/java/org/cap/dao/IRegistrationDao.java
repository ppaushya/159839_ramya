package org.cap.dao;

import org.cap.model.Registration;

public interface IRegistrationDao {
	public Registration createRegistration(Registration registration);
	

}
