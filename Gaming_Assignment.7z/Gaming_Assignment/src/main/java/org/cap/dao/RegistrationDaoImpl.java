package org.cap.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
//import java.util.logging.Logger;

import org.apache.log4j.Logger;
import org.cap.model.Registration;

//import org.cap.model.Customer;

public class RegistrationDaoImpl {
	final static Logger logger=Logger.getLogger(RegistrationDaoImpl.class);
	public Registration createRegistration(Registration registration)

	{

		
		try(Connection conn=getDbConnection()) {
		
			String sql="insert into registration(customerName,mobileNo,age,registrationFee,actualRegFee) values(?,?,?,?,?)";
				PreparedStatement statement=conn.prepareStatement(sql);
				
				statement.setString(1, registration.getCustName());
				statement.setString(2, registration.getMobileNo());
				statement.setInt(3, registration.getAge());
				statement.setDouble(4, registration.getRegFees());
				statement.setDouble(5, registration.getActualRegFees());
			
				int count=statement.executeUpdate();
				
				if(count>0)
				{
					System.out.println("registration successful");
					logger.error("Insertion done!");
					
				registration.setRegistrationId(getLatestRegistrationId());
				}
				else {
					System.out.println("error occured");
				logger.error("error occured");
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return registration;
	}
		private int getLatestRegistrationId() {
			try(Connection connection = getDbConnection()) {
				String sql = "select max(registrationId) from registration";
				PreparedStatement statement = connection.prepareStatement(sql);
				
				ResultSet resultSet = statement.executeQuery();
				while(resultSet.next()) {
					return resultSet.getInt(1);
				}
			} catch (SQLException e) {
				System.out.println(e.toString());
				e.printStackTrace();
			}
			return 100;
		}	
			
		
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}


}
