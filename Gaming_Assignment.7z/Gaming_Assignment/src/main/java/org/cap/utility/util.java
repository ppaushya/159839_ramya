package org.cap.utility;

public class util {

	public boolean validateMobileno(String mobileNo) {
		if(mobileNo.matches("[0-9]{3,}")) {
			return true;
		}
		return false;
		
		
	}
	
	public boolean validateCustomername(String customerName) {
		if(customerName.matches("[A-z]{1}[a-zA-Z]{3,}")) {
			return true;
		}
		return false;
		
		
	}
}
