package org.cap.boot;

import org.apache.log4j.Logger;

import org.cap.model.Customer;
import org.cap.service.CustomerServiceImpl;
import org.cap.service.ICustomerService;
import org.cap.view.UserInteraction;

public class BootClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
UserInteraction userinteraction =new UserInteraction();
ICustomerService customerservice=new CustomerServiceImpl();
Customer customer=new Customer();
customer=userinteraction.getdetails();

customerservice.createRegistration(customer);

	}

}
/*
public static void main(String[] args) {
	// TODO Auto-generated method stub
HelloExample obj=new HelloExample();
obj.runme("capgemini");
}
private void runme(String parameter) {
	if(logger.isDebugEnabled()) {
		logger.debug("Thid is a msg: "+parameter);
	}
	if(logger.isInfoEnabled()) {
		logger.info("this is a info: "+parameter);
	}
	try {
		int num1=43,num2=0;
		int num3=num1/num2;
	}
	catch(ArithmeticException e) {
		logger.error("something went wrong",e);
	}
	logger.warn("this is msg: "+parameter);
	logger.error("this is an error: "+parameter);
	logger.fatal("this is a fatal: "+parameter);
	
}*/
