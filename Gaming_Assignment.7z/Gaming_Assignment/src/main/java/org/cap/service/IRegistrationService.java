package org.cap.service;

import org.cap.exception.InvalidAgeException;
import org.cap.model.Registration;

public interface IRegistrationService {

	public Registration createRegistration(Registration registration1) throws InvalidAgeException;

	double calculateRegFee(double registrationFee, int age);
	

}
