package org.cap.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.cap.model.Customer;


public class CustomerServiceImpl implements ICustomerService {
	public void createRegistration(Customer customer)

	{

		String sql="insert into Registration values(?,?,?,?,?,?)";
		try(Connection conn=getDbConnection()) {
		
				
				PreparedStatement statement=conn.prepareStatement(sql);
				statement.setInt(1,customer.getRegistrationId());
				statement.setString(2, customer.getCustomerName());
				statement.setString(3, customer.getMobileNo());
				statement.setInt(4, customer.getAge());
				statement.setDouble(5, customer.getRegistrationFee());
				statement.setDouble(6, customer.getActualRegFee());
			
				
				

				int count=statement.executeUpdate();
				
				if(count>0)
					System.out.println("Insertion done!");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			
		}
	private Connection getDbConnection() {
		Connection connection=null;
		try{	
			Class.forName("com.mysql.jdbc.Driver");
			connection=DriverManager.getConnection
					("jdbc:mysql://localhost:3306/mydb", "root", "India123");
			return connection;
		}catch (ClassNotFoundException|SQLException e) {
			e.printStackTrace();
		}
		
		return null;
		
	}



	public double calculateRegFee(double registrationFee,int age) {
		double regfee=registrationFee;
		
		double actualfee=0.0;
		if(age>0&&age<18) {
			actualfee=registrationFee;
		}
		else if(age>18&&age<25) {
			actualfee=registrationFee+registrationFee*0.1;
		}
		else if(age>25&&age<50) {
			actualfee=registrationFee+registrationFee*0.2;
		}
		else
		{
			actualfee=registrationFee+registrationFee*0.3;
		}
		return actualfee;
		// TODO Auto-generated method stub
		
	}

}

