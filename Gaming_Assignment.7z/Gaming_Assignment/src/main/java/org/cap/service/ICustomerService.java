package org.cap.service;

import org.cap.model.Customer;

public interface ICustomerService {

	public double calculateRegFee(double registrationFee, int i);

	public void createRegistration(Customer customer);
		

}
