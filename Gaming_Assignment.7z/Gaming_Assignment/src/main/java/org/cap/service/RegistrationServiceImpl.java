package org.cap.service;

import java.util.logging.Logger;

import org.cap.dao.IRegistrationDao;
import org.cap.dao.RegistrationDaoImpl;
import org.cap.exception.InvalidAgeException;
import org.cap.model.Registration;

public class RegistrationServiceImpl implements IRegistrationService {

	 RegistrationDaoImpl regdao=new RegistrationDaoImpl();
	public RegistrationServiceImpl() {
		
	}
	public RegistrationServiceImpl(RegistrationDaoImpl registrationDao) {
		this.regdao=registrationDao;
	}


	public  Registration createRegistration(Registration registration1) throws InvalidAgeException  {
		// TODO Auto-generated method stub

		
		if(registration1==null)
			throw new IllegalArgumentException();
		else if(registration1.getAge()<8)
			throw new InvalidAgeException("sry..invalid age");
		else
			registration1.setActualRegFees(calculateRegFee(registration1.getRegFees(),registration1.getAge()));
		return regdao.createRegistration(registration1);
	}


	public double calculateRegFee(double registrationFee,int age) {
		double regfee=registrationFee;
		
		double actualfee=0.0;
		if(age>0&&age<18) {
			actualfee=registrationFee;
		}
		else if(age>18&&age<25) {
			actualfee=registrationFee+registrationFee*0.1;
		}
		else if(age>25&&age<50) {
			actualfee=registrationFee+registrationFee*0.2;
		}
		else
		{
			actualfee=registrationFee+registrationFee*0.3;
		}
		return actualfee;
		
		
	}
}
