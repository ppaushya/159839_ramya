package ConferenceReg;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	private WebDriver driver;
	private WebElement element;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\aeramya\\Downloads\\chromedriver.exe");
		 driver=new ChromeDriver();
	}
	@Given("^registration page$")
	public void registration_page() throws Throwable {
		driver.get("file:///C:/Users/aeramya/Desktop/Conferencebooking/ConferenceRegistartion.html#");
		
	}

	@When("^title is not Conference Registration$")
	public void title_is_not_Conference_Registration() throws Throwable {
		assertNotEquals("ConferenceRegistration", driver.getTitle());
	}

	@Then("^stop executing$")
	public void stop_executing() throws Throwable {
	    driver.quit();
	}

	@Given("^Conference Registration page$")
	public void conference_Registration_page() throws Throwable {
		driver.get("file:///C:/Users/aeramya/Desktop/Conferencebooking/ConferenceRegistartion.html#");
	}

	@When("^heading of the is not Step (\\d+): Personal Details$")
	public void heading_of_the_is_not_Step_Personal_Details(int arg1) throws Throwable {
	    String title=driver.findElement(By.xpath("/html/body/h4")).getText();
	   
	}
	@Then("^stop execution$")
	public void stop_execution() throws Throwable {
		String title=driver.findElement(By.xpath("/html/body/h4")).getText();
		assertNotEquals("Step 1:Personal Details",title );
	    driver.quit();
	}
	@Given("^registration details$")
	public void registration_details() throws Throwable {
		driver.get("file:///C:/Users/aeramya/Desktop/Conferencebooking/ConferenceRegistartion.html#");
	}

	@When("^enters correct details$")
	public void enters_correct_details() throws Throwable {
	    driver.findElement(By.name("txtFN")).sendKeys("rams");
	    driver.findElement(By.name("txtLN")).sendKeys("rams");
	    driver.findElement(By.name("Email")).sendKeys("rams@ravs.co");
	    driver.findElement(By.name("Phone")).sendKeys("9090909090");
	    Select sel=new Select(driver.findElement(By.name("size")));
	    sel.selectByValue("two");
	   
	    driver.findElement(By.name("Address")).sendKeys("hitech city");
	    driver.findElement(By.name("Address2")).sendKeys("hyd");
	    Select sel2=new Select(driver.findElement(By.name("city")));
	    sel2.selectByValue("Bangalore");
	    Select sel3=new Select(driver.findElement(By.name("state")));
	    sel3.selectByValue("Karnataka");
	    driver.findElement(By.name("memberStatus")).click();
	    

	    
	}

	@Then("^navigate to next page$")
	public void navigate_to_next_page() throws Throwable {
		driver.findElement(By.linkText("Next")).click();
		driver.switchTo().alert().accept();
	}
	

}
