package invalidDetails;

import org.junit.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	private WebDriver driver;
	private WebElement element;
	
	
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\aeramya\\Downloads\\chromedriver.exe");
		 driver=new ChromeDriver();
		 driver.get("file:///C:/Users/aeramya/Desktop/Conferencebooking/ConferenceRegistartion.html#");
	}
	@Given("^details except fname$")
	public void details_except_fname() throws Throwable {
		System.out.println( driver.findElement(By.name("txtFN")).isDisplayed());
		System.out.println( driver.findElement(By.name("txtLN")).isDisplayed());
		System.out.println( driver.findElement(By.name("Email")).isDisplayed());
		System.out.println( driver.findElement(By.name("Phone")).isDisplayed());
		System.out.println(driver.findElement(By.name("size")).isDisplayed());
		System.out.println( driver.findElement(By.name("Address")).isDisplayed());
		System.out.println( driver.findElement(By.name("Address2")).isDisplayed());
		System.out.println( driver.findElement(By.name("city")).isDisplayed());
		System.out.println( driver.findElement(By.name("state")).isDisplayed());
		System.out.println( driver.findElement(By.name("memberStatus")).isDisplayed());
		
		    driver.findElement(By.name("txtLN")).sendKeys("rams");
		    driver.findElement(By.name("Email")).sendKeys("rams@ravs.co");
		    driver.findElement(By.name("Phone")).sendKeys("9090909090");
		    Select sel=new Select(driver.findElement(By.name("size")));
		    sel.selectByValue("two");		   
		    driver.findElement(By.name("Address")).sendKeys("hitech city");
		    driver.findElement(By.name("Address2")).sendKeys("hyd");
		    Select sel2=new Select(driver.findElement(By.name("city")));
		    sel2.selectByValue("Bangalore");
		    Select sel3=new Select(driver.findElement(By.name("state")));
		    sel3.selectByValue("Karnataka");
		    driver.findElement(By.name("memberStatus")).click();
	}

	@When("^clicking next without fname$")
	public void clicking_next_without_fname() throws Throwable {
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^display invalid fname in alert box$")
	public void display_invalid_fname_in_alert_box() throws Throwable {
		driver.switchTo().alert().accept();
	}

	@Given("^details except lname$")
	public void details_except_lname() throws Throwable {
		 driver.findElement(By.name("txtFN")).sendKeys("rams");
		    driver.findElement(By.name("txtLN"));
		    driver.findElement(By.name("Email")).sendKeys("rams@ravs.co");
		    driver.findElement(By.name("Phone")).sendKeys("9090909090");
		    Select sel=new Select(driver.findElement(By.name("size")));
		    sel.selectByValue("two");
		   
		    driver.findElement(By.name("Address")).sendKeys("hitech city");
		    driver.findElement(By.name("Address2")).sendKeys("hyd");
		    Select sel2=new Select(driver.findElement(By.name("city")));
		    sel2.selectByValue("Bangalore");
		    Select sel3=new Select(driver.findElement(By.name("state")));
		    sel3.selectByValue("Karnataka");
		    driver.findElement(By.name("memberStatus")).click();
	}

	@When("^clicking next without lname$")
	public void clicking_next_without_lname() throws Throwable {
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^display invalid lname in alert box$")
	public void display_invalid_lname_in_alert_box() throws Throwable {
		driver.switchTo().alert().accept();
	}

	@Given("^details except email$")
	public void details_except_email() throws Throwable {
		 driver.findElement(By.name("txtFN")).sendKeys("rams");
		    driver.findElement(By.name("txtLN")).sendKeys("rams");
		    driver.findElement(By.name("Email"));
		    driver.findElement(By.name("Phone")).sendKeys("9090909090");
		    Select sel=new Select(driver.findElement(By.name("size")));
		    sel.selectByValue("two");		   
		    driver.findElement(By.name("Address")).sendKeys("hitech city");
		    driver.findElement(By.name("Address2")).sendKeys("hyd");
		    Select sel2=new Select(driver.findElement(By.name("city")));
		    sel2.selectByValue("Bangalore");
		    Select sel3=new Select(driver.findElement(By.name("state")));
		    sel3.selectByValue("Karnataka");
		    driver.findElement(By.name("memberStatus")).click();
	}

	@When("^clicking next without email$")
	public void clicking_next_without_email() throws Throwable {
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^display invalid email in alert box$")
	public void display_invalid_email_in_alert_box() throws Throwable {
		driver.switchTo().alert().accept();
	}

	@Given("^details except contactNo$")
	public void details_except_contactNo() throws Throwable {
		 driver.findElement(By.name("txtFN")).sendKeys("rams");
		    driver.findElement(By.name("txtLN")).sendKeys("ravs");
		    driver.findElement(By.name("Email")).sendKeys("rams@ravs.co");
		    driver.findElement(By.name("Phone"));
		    Select sel=new Select(driver.findElement(By.name("size")));
		    sel.selectByValue("two");
		   
		    driver.findElement(By.name("Address")).sendKeys("hitech city");
		    driver.findElement(By.name("Address2")).sendKeys("hyd");
		    Select sel2=new Select(driver.findElement(By.name("city")));
		    sel2.selectByValue("Bangalore");
		    Select sel3=new Select(driver.findElement(By.name("state")));
		    sel3.selectByValue("Karnataka");
		    driver.findElement(By.name("memberStatus")).click();
	}

	@When("^clicking next without contactNo$")
	public void clicking_next_without_contactNo() throws Throwable {
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^display invalid contactNo in alert box$")
	public void display_invalid_contactNo_in_alert_box() throws Throwable {
		driver.switchTo().alert().accept();
	}

	@Given("^details except no\\.of people attending$")
	public void details_except_no_of_people_attending() throws Throwable {
		 driver.findElement(By.name("txtFN")).sendKeys("rams");
		    driver.findElement(By.name("txtLN")).sendKeys("ravs");
		    driver.findElement(By.name("Email")).sendKeys("rams@ravs.co");
		    driver.findElement(By.name("Phone")).sendKeys("9090909090");
		    
		    driver.findElement(By.name("Address")).sendKeys("hitech city");
		    driver.findElement(By.name("Address2")).sendKeys("hyd");
		    Select sel2=new Select(driver.findElement(By.name("city")));
		    sel2.selectByValue("Bangalore");
		    Select sel3=new Select(driver.findElement(By.name("state")));
		    sel3.selectByValue("Karnataka");
		    driver.findElement(By.name("memberStatus")).click();
	}

	@When("^clicking next without no\\.of people attending$")
	public void clicking_next_without_no_of_people_attending() throws Throwable {
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^display invalid no\\.of people attending in alert box$")
	public void display_invalid_no_of_people_attending_in_alert_box() throws Throwable {
		driver.switchTo().alert().accept();
	}

	@Given("^details except buildingName$")
	public void details_except_buildingName() throws Throwable {
		 driver.findElement(By.name("txtFN")).sendKeys("rams");
		    driver.findElement(By.name("txtLN")).sendKeys("ravs");
		    driver.findElement(By.name("Email")).sendKeys("rams@ravs.co");
		    driver.findElement(By.name("Phone")).sendKeys("9090909090");
		    Select sel=new Select(driver.findElement(By.name("size")));
		    sel.selectByValue("two");
		   
		    driver.findElement(By.name("Address"));
		    driver.findElement(By.name("Address2")).sendKeys("hyd");
		    Select sel2=new Select(driver.findElement(By.name("city")));
		    sel2.selectByValue("Bangalore");
		    Select sel3=new Select(driver.findElement(By.name("state")));
		    sel3.selectByValue("Karnataka");
		    driver.findElement(By.name("memberStatus")).click();
	}

	@When("^clicking next without buildingName$")
	public void clicking_next_without_buildingName() throws Throwable {
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^display invalid buildingName in alert box$")
	public void display_invalid_buildingName_in_alert_box() throws Throwable {
		driver.switchTo().alert().accept();
	}

	@Given("^details except areaName$")
	public void details_except_areaName() throws Throwable {
		 driver.findElement(By.name("txtFN")).sendKeys("rams");
		    driver.findElement(By.name("txtLN")).sendKeys("ravs");
		    driver.findElement(By.name("Email")).sendKeys("rams@ravs.co");
		    driver.findElement(By.name("Phone")).sendKeys("9090909090");
		    Select sel=new Select(driver.findElement(By.name("size")));
		    sel.selectByValue("two");
		   
		    driver.findElement(By.name("Address")).sendKeys("hitech city");
		    driver.findElement(By.name("Address2"));
		    Select sel2=new Select(driver.findElement(By.name("city")));
		    sel2.selectByValue("Bangalore");
		    Select sel3=new Select(driver.findElement(By.name("state")));
		    sel3.selectByValue("Karnataka");
		    driver.findElement(By.name("memberStatus")).click();
	}

	@When("^clicking next without areaName$")
	public void clicking_next_without_areaName() throws Throwable {
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^display invalid areaName in alert box$")
	public void display_invalid_areaName_in_alert_box() throws Throwable {
		driver.switchTo().alert().accept();
	}

	@Given("^details except city$")
	public void details_except_city() throws Throwable {
		 driver.findElement(By.name("txtFN")).sendKeys("rams");
		    driver.findElement(By.name("txtLN")).sendKeys("ravs");
		    driver.findElement(By.name("Email")).sendKeys("rams@ravs.co");
		    driver.findElement(By.name("Phone")).sendKeys("9090909090");
		    Select sel=new Select(driver.findElement(By.name("size")));
		    sel.selectByValue("two");
		   
		    driver.findElement(By.name("Address")).sendKeys("hitech city");
		    driver.findElement(By.name("Address2")).sendKeys("hyd");
		   
		    Select sel3=new Select(driver.findElement(By.name("state")));
		    sel3.selectByValue("Karnataka");
		    driver.findElement(By.name("memberStatus")).click();
	}

	@When("^clicking next without city$")
	public void clicking_next_without_city() throws Throwable {
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^display invalid city in alert box$")
	public void display_invalid_city_in_alert_box() throws Throwable {
		driver.switchTo().alert().accept();
	}

	@Given("^details except state$")
	public void details_except_state() throws Throwable {
		 driver.findElement(By.name("txtFN")).sendKeys("rams");
		    driver.findElement(By.name("txtLN")).sendKeys("ravs");
		    driver.findElement(By.name("Email")).sendKeys("rams@ravs.co");
		    driver.findElement(By.name("Phone")).sendKeys("9090909090");
		    Select sel=new Select(driver.findElement(By.name("size")));
		    sel.selectByValue("two");
		   
		    driver.findElement(By.name("Address")).sendKeys("hitech city");
		    driver.findElement(By.name("Address2")).sendKeys("hyd");
		    Select sel2=new Select(driver.findElement(By.name("city")));
		    sel2.selectByValue("Bangalore");
		   
		    driver.findElement(By.name("memberStatus")).click();
	}

	@When("^clicking next without state$")
	public void clicking_next_without_state() throws Throwable {
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^display invalid state in alert box$")
	public void display_invalid_state_in_alert_box() throws Throwable {
		driver.switchTo().alert().accept();
	}

	@Given("^details except fullAccess$")
	public void details_except_fullAccess() throws Throwable {
		 driver.findElement(By.name("txtFN")).sendKeys("rams");
		    driver.findElement(By.name("txtLN")).sendKeys("ravs");
		    driver.findElement(By.name("Email")).sendKeys("rams@ravs.co");
		    driver.findElement(By.name("Phone")).sendKeys("9090909090");
		    Select sel=new Select(driver.findElement(By.name("size")));
		    sel.selectByValue("two");
		   
		    driver.findElement(By.name("Address")).sendKeys("hitech city");
		    driver.findElement(By.name("Address2")).sendKeys("hyd");
		    Select sel2=new Select(driver.findElement(By.name("city")));
		    sel2.selectByValue("Bangalore");
		    Select sel3=new Select(driver.findElement(By.name("state")));
		    sel3.selectByValue("Karnataka");
		   
	}

	@When("^clicking next without fullAccess$")
	public void clicking_next_without_fullAccess() throws Throwable {
		driver.findElement(By.linkText("Next")).click();
	}

	@Then("^display invalid fullAccess in alert box$")
	public void display_invalid_fullAccess_in_alert_box() throws Throwable {
		driver.switchTo().alert().accept();
	}
}
