package org.cap.demo2;

import java.util.Scanner;

public class Assign_Q_4 {
	int a;int n;int c;String num;
public boolean isArmstrong1(int n) {
	int k=n;
	c=0;  
	while(n>0)  
	    {  
	    a=n%10;  
	    n=n/10;  
	    c=c+(a*a*a);  
	    }  
	  if(c!=k)
		  return false;
	  else
		  return true;
		  
}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Assign_Q_4 cls=new Assign_Q_4();
		
			for(int i=0;i<1000;i++) {
				if(cls.isArmstrong1(i))
					System.out.print(" "+i+", ");
			}
		}
	}


