package org.cap.demo2;

import java.util.Scanner;

public class Assign_Q2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n,m;int sum=0;int x;String a;
		Scanner s= new Scanner(System.in);
		System.out.print(" Enter Number");
		n=s.nextInt();
		/*a=Integer.toString(n);
		x=a.length();
		for(int i=0;i<=x;i++) {
			arr[i]= a.charAt(i);
		}
		for(int i=0;i<=x;i++) {
			sum=sum+ arr[i];*/
		while(n>0) {
		m=n%10;
		sum+=m;
		n=n/10;}
		System.out.print(" "+sum);
		}
	}

