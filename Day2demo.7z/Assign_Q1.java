package org.cap.demo2;
public class Assign_Q1 {
	public void assig_Q1(int num)

    {

           int i=0;

           int x=1;

           int y=2;

           while(x<num)

           {
                  for(i=0;i<3;)

           {
                  if(x%2!=0)

                  {
                        System.out.print(x+" ");

                        i++;
                  }
                  x++;

                  if(x>=num)

                        break;

           }

                  for(int j=0;j<3;)

                  {

                  if(y%2==0)

                  {
                        System.out.print(y+" ");

                        j++;

                  }

                  y++;

                  if(y>=num)

                        break;

                  }

           }

           }
	public static void main(String[] args) {
		Assign_Q1 fun=new Assign_Q1();
	fun.assig_Q1(20);

	}
}
