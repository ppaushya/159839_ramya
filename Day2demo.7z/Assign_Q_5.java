package org.cap.demo2;

import java.util.Scanner;

public class Assign_Q_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String n;char l; int x;;
		Scanner s= new Scanner(System.in);
		System.out.print(" Enter String");
		n=s.nextLine();
		x=n.length();
		for(int i=0;i<x;i++) {
			for(int j=0;j<=i;j++) {
				l= n.charAt(j);
				System.out.print(" "+l);
		}
			System.out.println();
	}
	}
}
